import json
import csv
import os
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

# ── All files are read from / saved to the SAME folder as this script ──
# This works on Windows, Linux, and Mac automatically.
FOLDER = os.path.dirname(os.path.abspath(__file__))

def path(filename):
    return os.path.join(FOLDER, filename)

# ── Colors ──────────────────────────────────────────────────
STEP_COLORS = {
    'Kmer Table Build':      '#2E5FA3',
    'Reference Index Build': '#5B8DD9',
    'Signal Normalization':  '#E07B39',
    'Event Detection':       '#F5A623',
    'Query Minimizers':      '#2E8B57',
    'Seeding':               '#8BC34A',
    'DTW Alignment':         '#C0392B',
    'Chaining & Mapping':    '#E67E22',
}

plt.rcParams.update({
    'font.family': 'DejaVu Sans',
    'font.size':        11,
    'axes.titlesize':   13,
    'axes.labelsize':   11,
    'axes.spines.top':   False,
    'axes.spines.right': False,
    'figure.facecolor': '#F7F9FC',
    'axes.facecolor':   '#F7F9FC',
})

# ── Load rawhash_results.json (created by ./rawhash) ────────
json_path = path('rawhash_results.json')
if not os.path.exists(json_path):
    print(f"ERROR: Could not find {json_path}")
    print("Make sure you ran:  ./rawhash 5000 500  first!")
    exit(1)

with open(json_path) as f:
    data = json.load(f)

# Support both old format (no phase) and new format (with phase)
steps = data['steps']
has_phase = 'phase' in steps[0]

if has_phase:
    offline_steps = [s for s in steps if s['phase'] == 'OFFLINE']
    online_steps  = [s for s in steps if s['phase'] == 'ONLINE']
    offline_total = data.get('offline_total', sum(s['total'] for s in offline_steps))
    online_total  = data.get('online_total',  sum(s['total'] for s in online_steps))
else:
    # Old format: treat all stages as one group
    offline_steps = []
    online_steps  = steps
    offline_total = 0
    online_total  = data.get('grand_total', sum(s['total'] for s in steps))

grand_total = data.get('grand_total', offline_total + online_total)
ref_len     = data['ref_len']
query_len   = data['query_len']

print(f"Loaded: {len(steps)} steps, grand total = {grand_total:,} cycles")

# ════════════════════════════════════════════════════════════
#  FIGURE 1: Per-stage cycle bar chart + pie + op breakdown
# ════════════════════════════════════════════════════════════
fig, axes = plt.subplots(1, 3, figsize=(18, 7))
fig.suptitle(
    f'RawHash Pipeline — Cycle Analysis\n'
    f'Ref: {ref_len} bp  |  Query: {query_len} bp  |  Grand Total: {grand_total:,} cycles',
    fontsize=14, fontweight='bold', y=1.01
)

# Plot 1: Horizontal bar — cycles per stage
ax = axes[0]
names  = [s['name']  for s in steps]
totals = [s['total'] for s in steps]
colors = [STEP_COLORS.get(s['name'], '#999999') for s in steps]
y = range(len(steps))
bars = ax.barh(list(y), totals, color=colors, edgecolor='white', height=0.7)
ax.set_yticks(list(y))
ax.set_yticklabels(names, fontsize=9)
ax.set_xlabel('Total Cycles')
ax.set_title('Cycles per Stage')
ax.xaxis.set_major_formatter(plt.FuncFormatter(
    lambda x, _: f'{x/1e6:.1f}M' if x >= 1e6 else f'{x/1e3:.0f}K'))
for bar, val in zip(bars, totals):
    ax.text(bar.get_width() * 1.01, bar.get_y() + bar.get_height()/2,
            f'{val:,}', va='center', fontsize=7.5)

# Plot 2: Pie chart — share of total cycles
ax2 = axes[1]
nonzero = [(s['name'], s['total']) for s in steps if s['total'] > 0]
pie_names, pie_vals = zip(*nonzero) if nonzero else ([], [])
pie_colors = [STEP_COLORS.get(n, '#999') for n in pie_names]
wedges, texts, autotexts = ax2.pie(
    pie_vals, colors=pie_colors,
    autopct=lambda p: f'{p:.1f}%' if p > 3 else '',
    startangle=90, pctdistance=0.75,
    wedgeprops={'edgecolor': 'white', 'linewidth': 1.5}
)
for at in autotexts: at.set_fontsize(8)
ax2.legend(wedges, [n[:20] for n in pie_names],
           loc='lower center', bbox_to_anchor=(0.5, -0.18),
           ncol=2, fontsize=7.5, frameon=False)
ax2.set_title('Cycle Share by Stage')

# Plot 3: Stacked bar — op type breakdown per stage
ax3 = axes[2]
x = np.arange(len(steps))
w = 0.6
op_data = [
    ([s['arith']   * 1  for s in steps], '#4E79A7', 'Arith (×1)'),
    ([s['mem']     * 10 for s in steps], '#E15759', 'Memory (×10)'),
    ([s['compare'] * 1  for s in steps], '#59A14F', 'Compare (×1)'),
    ([s['mac']     * 1  for s in steps], '#F28E2B', 'MAC (×1)'),
]
bottom = np.zeros(len(steps))
for vals, color, label in op_data:
    ax3.bar(x, vals, w, bottom=bottom, color=color, label=label, edgecolor='white')
    bottom += np.array(vals)
ax3.set_xticks(x)
ax3.set_xticklabels([n.replace(' ', '\n') for n in names], fontsize=7.5)
ax3.set_ylabel('Weighted Cycles')
ax3.set_title('Op Type Breakdown per Stage')
ax3.legend(fontsize=8, frameon=False, loc='upper right')
ax3.yaxis.set_major_formatter(plt.FuncFormatter(
    lambda x, _: f'{x/1e6:.1f}M' if x >= 1e6 else f'{x/1e3:.0f}K'))

plt.tight_layout()
out1 = path('rawhash_stage_analysis.png')
plt.savefig(out1, dpi=150, bbox_inches='tight')
plt.close()
print(f"Saved: rawhash_stage_analysis.png")

# ════════════════════════════════════════════════════════════
#  FIGURE 2: Offline vs Online + ReRAM estimation
# ════════════════════════════════════════════════════════════
fig2, axes2 = plt.subplots(1, 3, figsize=(18, 6))
fig2.suptitle('RawHash — Offline vs Online & ReRAM Estimation', fontsize=14, fontweight='bold')

# Plot 1: Offline vs Online bar
ax = axes2[0]
phases = ['OFFLINE\n(one-time)', 'ONLINE\n(per read)']
vals   = [offline_total, online_total]
cols   = ['#2E5FA3', '#C0392B']
bars   = ax.bar(phases, vals, color=cols, width=0.45, edgecolor='white')
ax.set_ylabel('Total Cycles')
ax.set_title('Offline vs Online Cost')
ax.yaxis.set_major_formatter(plt.FuncFormatter(
    lambda x, _: f'{x/1e6:.1f}M' if x >= 1e6 else f'{x/1e3:.0f}K'))
for bar, val, note in zip(bars, vals, ['paid once', 'every read!']):
    ax.text(bar.get_x() + bar.get_width()/2,
            bar.get_height() + grand_total * 0.01,
            f'{val:,}\n({note})', ha='center', fontsize=9, fontweight='bold')
ax.set_ylim(0, max(vals) * 1.4)
ax.annotate('ReRAM\naccelerates\nTHIS →',
    xy=(1, online_total * 0.5), xytext=(1.42, online_total * 0.72),
    fontsize=9, color='#C0392B', fontweight='bold',
    arrowprops=dict(arrowstyle='->', color='#C0392B', lw=2))

# Plot 2: DTW vs rest of online
ax = axes2[1]
dtw_s    = next((s for s in steps if 'DTW' in s['name']), None)
dtw_cyc  = dtw_s['total'] if dtw_s else 0
rest_cyc = online_total - dtw_cyc
ax.pie(
    [dtw_cyc, rest_cyc],
    labels=[f"DTW\n{dtw_cyc:,}", f"Rest of online\n{rest_cyc:,}"],
    colors=['#C0392B', '#AED6F1'],
    autopct='%1.1f%%', startangle=90,
    wedgeprops={'edgecolor': 'white', 'linewidth': 2}
)
ax.set_title('DTW vs Rest\n(Online Phase)')

# Plot 3: ReRAM estimation bar chart
ax = axes2[2]
total_mac  = sum(s['mac']     for s in online_steps) if online_steps else sum(s['mac']     for s in steps)
total_mem  = sum(s['mem']     for s in online_steps) if online_steps else sum(s['mem']     for s in steps)
total_arith= sum(s['arith']   for s in online_steps) if online_steps else sum(s['arith']   for s in steps)
total_cmp  = sum(s['compare'] for s in online_steps) if online_steps else sum(s['compare'] for s in steps)

# Latency values (ns per operation) — REPLACE with sir's paper values
scenarios = {
    'CPU\n3GHz':           {'mac':0.33, 'mem':0.33,  'arith':0.33, 'cmp':0.33},
    'ReRAM\nOptimistic':   {'mac':0.1,  'mem':2.0,   'arith':0.5,  'cmp':0.3 },
    'ReRAM\nTypical':      {'mac':0.5,  'mem':5.0,   'arith':1.0,  'cmp':0.5 },
    'ReRAM\nPessimistic':  {'mac':1.0,  'mem':10.0,  'arith':2.0,  'cmp':1.0 },
}
sc_names = list(scenarios.keys())
sc_times = [
    (total_mac*sc['mac'] + total_mem*sc['mem'] +
     total_arith*sc['arith'] + total_cmp*sc['cmp']) / 1e6
    for sc in scenarios.values()
]
sc_colors = ['#2E5FA3', '#27AE60', '#F39C12', '#C0392B']
bars = ax.bar(sc_names, sc_times, color=sc_colors, edgecolor='white', width=0.5)
ax.set_ylabel('Estimated Time (ms)\nper read')
ax.set_title('CPU vs ReRAM Estimated Time\n(replace values with sir\'s paper)')
for bar, val in zip(bars, sc_times):
    ax.text(bar.get_x() + bar.get_width()/2,
            bar.get_height() + max(sc_times)*0.01,
            f'{val:.2f}ms', ha='center', fontsize=9)
ax.text(0.5, 0.96,
    '★ Update latency values in plot_results.py',
    transform=ax.transAxes, ha='center', fontsize=8,
    bbox=dict(boxstyle='round', facecolor='#FFFACD', alpha=0.9))

plt.tight_layout()
out2 = path('rawhash_offline_online.png')
plt.savefig(out2, dpi=150, bbox_inches='tight')
plt.close()
print(f"Saved: rawhash_offline_online.png")

# ════════════════════════════════════════════════════════════
#  FIGURE 3: Summary table
# ════════════════════════════════════════════════════════════
fig3, ax = plt.subplots(figsize=(15, 6))
ax.axis('off')
fig3.patch.set_facecolor('#F7F9FC')

rows = []
for s in steps:
    pct = 100 * s['total'] / grand_total if grand_total > 0 else 0
    phase = s.get('phase', 'ONLINE')
    rows.append([phase, s['name'],
                 f"{s['arith']:,}", f"{s['mem']:,}",
                 f"{s['compare']:,}", f"{s['mac']:,}",
                 f"{s['total']:,}", f"{pct:.1f}%"])

rows.append(['', '─'*22, '', '', '', '', '', ''])
rows.append(['OFFLINE', 'SUBTOTAL (one-time)', '', '', '', '',
             f"{offline_total:,}", f"{100*offline_total/grand_total:.1f}%"])
rows.append(['ONLINE',  'SUBTOTAL (per read)', '', '', '', '',
             f"{online_total:,}",  f"{100*online_total/grand_total:.1f}%"])
rows.append(['', 'GRAND TOTAL', '', '', '', '',
             f"{grand_total:,}", "100%"])

col_labels = ['Phase', 'Step', 'Arith Ops', 'Mem Ops',
              'Cmp Ops', 'MAC Ops', 'Total Cycles', '% Share']

tbl = ax.table(cellText=rows, colLabels=col_labels, loc='center', cellLoc='center')
tbl.auto_set_font_size(False)
tbl.set_fontsize(9)
tbl.scale(1, 1.55)

# Header
for j in range(len(col_labels)):
    tbl[(0, j)].set_facecolor('#1A3A6B')
    tbl[(0, j)].set_text_props(color='white', fontweight='bold')

# Row colors
for i, row in enumerate(rows):
    if 'SUBTOTAL' in row[1] or 'GRAND' in row[1]:
        for j in range(len(col_labels)):
            tbl[(i+1, j)].set_facecolor('#2C3E50')
            tbl[(i+1, j)].set_text_props(color='white', fontweight='bold')
        continue
    bg = '#D6E4F7' if row[0] == 'OFFLINE' else '#FFF0E6' if row[0] == 'ONLINE' else 'white'
    if 'DTW' in row[1]: bg = '#FADBD8'
    for j in range(len(col_labels)):
        tbl[(i+1, j)].set_facecolor(bg)

ax.set_title(
    f'RawHash Cycle Count Table — Ref: {ref_len} bp | Query: {query_len} bp\n'
    f'Blue = OFFLINE  |  Orange = ONLINE  |  Red = DTW (heaviest step)',
    fontsize=11, fontweight='bold', pad=20
)

plt.tight_layout()
out3 = path('rawhash_cycle_table.png')
plt.savefig(out3, dpi=150, bbox_inches='tight')
plt.close()
print(f"Saved: rawhash_cycle_table.png")

print("\n✅ All 3 graphs saved in the same folder as this script!")
print(f"   Folder: {FOLDER}")
